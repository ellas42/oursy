const products = [
  { id: 1, name: 'Sport Kini', stock: 1, price: 149999, image: 'frontend/images/bikini-blackpink1-removebg-preview.png' },
  { id: 2, name: 'Midnight Blue', stock: 4, price: 169999, image: 'frontend/images/bikini-blue1-removebg-preview.png' },
  { id: 3, name: 'Wood Land', stock: 2, price: 129999, image: 'frontend/images/bikini-motif1-removebg-preview.png' },
  { id: 4, name: 'Sunset Glow', stock: 2, price: 129999, image: 'frontend/images/bikini-orangepurple1-removebg-preview.png' },
  { id: 5, name: 'Hearts of Ours', stock: 3, price: 169999, image: 'frontend/images/bikini-red1-removebg-preview.png' },
  { id: 6, name: 'Coral Reef Set', stock: 2, price: 149999, image: 'frontend/images/bikini-skyblue1-removebg-preview.png' },
  { id: 7, name: 'Tropical Dusk Set', stock: 1, price: 129999, image: 'frontend/images/bikini-cherry1-removebg-preview.png' },
  { id: 8, name: 'Lagoon Blue Set', stock: 1, price: 139999, image: 'frontend/images/bikini-brown1-removebg-preview.png' },
];