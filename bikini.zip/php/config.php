<?php 
define('OWNER_EMAIL', 'ellalianaa06@gmail.com');
define('SITE_NAME', 'Oursy');
define('FROM_EMAIL', 'ellalianaa06@gmail.com');

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'ellalianaa06@gmail.com');
define('SMTP_PASSWORD', 'rekyjlfqxpuhypzy');
?>